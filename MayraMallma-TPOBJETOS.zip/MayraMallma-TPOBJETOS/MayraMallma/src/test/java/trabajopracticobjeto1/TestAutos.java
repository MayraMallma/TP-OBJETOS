package trabajopracticobjeto1;

import trabajopracticobjeto1.autos.AutoClasico;
import trabajopracticobjeto1.autos.AutoNuevo;
import trabajopracticobjeto1.autos.Bondi;
import trabajopracticobjeto1.autos.Radio;

public class TestAutos {
    public static void main(String[] args) {
        System.out.println("Auto nuevo con radio NUEVA");
        AutoNuevo NuevoAuto1 = new AutoNuevo("Chevrolet", "Captiva", "Negro", 20000);
        Radio RadioNueva = new Radio("Sonic", "23000");
        NuevoAuto1.nuevaRadio(RadioNueva);
        System.out.println(NuevoAuto1);

        System.out.println("Auto nuevo con radio COMUN");
        AutoNuevo NuevoAuto2= new AutoNuevo("Citroen", "Aircross", "verde", 500000);
        System.out.println(NuevoAuto2);

        System.out.println("Bondi con radio NUEVA");
        Bondi Bondi1= new Bondi("160", "Cartel Gris", "Rojo", 1500500);
        Radio RadioColectivo = new Radio("Scarlet", "98233");
        Bondi1.agregarRadio(RadioColectivo);
        System.out.println(Bondi1);

        System.out.println("Bondi SIN radio");
        Bondi Bondi2= new Bondi("126", "Tablada", "Rojo", 36985);
        System.out.println(Bondi2);

        System.out.println("Auto SIN precio");
        AutoNuevo NuevoAuto3= new AutoNuevo("Ferrari", "Laferrari", "Azul", 0);
        System.out.println(NuevoAuto3);

        System.out.println("Auto Clasico CON radio");
        AutoClasico AutoClasico1= new AutoClasico("Ford", "Bronco", "Verde", 638384);
        Radio RadioNueva1= new Radio("Philips", "3468465");
        AutoClasico1.agregarRadio(RadioNueva1);
        System.out.println(AutoClasico1);

        System.out.println("Auto Clasico SIN RADIO");
        AutoClasico AutoClasico2= new AutoClasico("honda", "nsx", "Blanco", 648485);
        System.out.println(AutoClasico2);










    }
}
