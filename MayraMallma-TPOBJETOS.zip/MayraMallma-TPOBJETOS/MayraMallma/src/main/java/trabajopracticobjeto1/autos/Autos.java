package trabajopracticobjeto1.autos;

import lombok.Getter;
import lombok.ToString;

@Getter
@ToString

public abstract class Autos {
    private String marca;
    private String modelo;
    private String color;
    private double precio;
    
    public Autos(String marca, String modelo, String color, Double precio) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.precio = precio;
    }

}


