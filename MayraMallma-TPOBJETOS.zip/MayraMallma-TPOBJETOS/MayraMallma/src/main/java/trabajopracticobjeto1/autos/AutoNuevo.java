package trabajopracticobjeto1.autos;

import lombok.ToString;

@ToString

public class AutoNuevo extends Autos {
    private String marca;
    private String modelo;
    private String color;
    private double precio;
    private Radio radio;

    
    public AutoNuevo(String marca, String modelo, String color, double precio) {
        super(marca, modelo, color, precio);
        this.marca=marca;
        this.modelo=modelo;
        this.color=color;
        this.precio=precio;
        this.radio= new Radio("RadioAutoNuevo", "23000KW");

    }

        public void nuevaRadio(Radio radio){
            this.radio=radio;
        }
    
    
}
