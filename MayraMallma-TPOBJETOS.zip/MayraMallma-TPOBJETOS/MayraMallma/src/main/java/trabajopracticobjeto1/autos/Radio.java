package trabajopracticobjeto1.autos;

import lombok.ToString;

@ToString
public class Radio {
    private String marca;
    private String potencia;


    public String getMarca() {
        return marca;
    }
    public String getPotencia() {
        return potencia;

        
    }
    public Radio(String marca, String potencia) {
        this.marca = marca;
        this.potencia = potencia;
    }
    
}

